self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "b8913ce29f87a44c08ea735c25850fa0",
    "url": "/index.html"
  },
  {
    "revision": "c78f808a5f7fc670505e",
    "url": "/static/css/main.d1b05096.chunk.css"
  },
  {
    "revision": "6a9b76447411a3d0dc3f",
    "url": "/static/js/2.823bbc42.chunk.js"
  },
  {
    "revision": "6f5f1c4a5f7f6e382b8aeca1b4ac8d96",
    "url": "/static/js/2.823bbc42.chunk.js.LICENSE.txt"
  },
  {
    "revision": "c78f808a5f7fc670505e",
    "url": "/static/js/main.205daa03.chunk.js"
  },
  {
    "revision": "464c8a6eee638933db9f",
    "url": "/static/js/runtime-main.c83a4d79.js"
  },
  {
    "revision": "5d5d9eefa31e5e13a6610d9fa7a283bb",
    "url": "/static/media/logo.5d5d9eef.svg"
  }
]);